var finesse = finesse || {};
finesse.gadget = finesse.gadget || {};
finesse.container = finesse.container || {};

/*global logFinesse */

/** @namespace */
finesse.modules = finesse.modules || {};
finesse.modules.SampleGadget = (function ($) {

    /** @scope finesse.modules.SampleGadget */
    return {
        /**
         * Performs all initialization for this gadget
         */
        init : function () {
            
        }
    };
}(jQuery));